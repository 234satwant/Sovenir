<?php
$get = "pop";
echo "lol";
?>

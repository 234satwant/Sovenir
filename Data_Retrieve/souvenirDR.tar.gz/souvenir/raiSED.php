<?php
$OrgText[0] = "#"; $ReplacedText[0] = "\#";
$OrgText[] = "%"; $ReplacedText[] = "\%";
$OrgText[] = "&"; $ReplacedText[] = "\&";
//$OrgText[] = "~"; $ReplacedText[] = "\~";
$OrgText[] = "_"; $ReplacedText[] = "\_";
//$OrgText[] = " \""; $ReplacedText[] = " ``";
$OrgText[] = "{"; $ReplacedText[] = "\{";
$OrgText[] = "}"; $ReplacedText[] = "\}";
//$OrgText[] = "\" "; $ReplacedText[] = "'' ";
//$OrgText[] = "ghai"; $ReplacedText[] = "GHAIHSRAI XXXXXXXXX ";
$OrgText[] = "$"; $ReplacedText[] = "\\$";
//$OrgText[] = "."; $ReplacedText[] = ". ";
$OrgText[] = "'"; $ReplacedText[] = "`";
$OrgText[] = "` "; $ReplacedText[] = "' " ;
$OrgText[] = "`."; $ReplacedText[] = "'.";
//$OrgText[] = "`s"; $ReplacedText[] = "'s"; //15th amendment
$OrgText[] = "\""; $ReplacedText[] = "``";
$OrgText[] = "`` "; $ReplacedText[] = "'' " ;
$OrgText[] = "``."; $ReplacedText[] = "''." ;
$OrgText[] = ", , "; $ReplacedText[] = ", ";
//$OrgText[] = ", , "; $ReplacedText[] = ", , ";

?>
